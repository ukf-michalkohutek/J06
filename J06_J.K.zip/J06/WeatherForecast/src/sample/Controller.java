package sample;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.util.Duration;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Controller {

    private static double latitude;
    private static double longitude;
    private static int[] temperatures = new int[4];
    private static String[] weathers = new String[4];
    private static String[] icons = new String[4];
    @FXML
    private ImageView background;
    @FXML
    private Label labelTime;
    @FXML
    private TextField cityField;
    @FXML
    private TextField cityField1;
    @FXML
    private Label labelTemp;
    @FXML
    private Label labelTemp1;
    @FXML
    private ImageView imgWeather;
    @FXML
    private ImageView imgWeather1;
    @FXML
    private Label forecast1;
    @FXML
    private ImageView forecastImg1;
    @FXML
    private Label forecast2;
    @FXML
    private ImageView forecastImg2;
    @FXML
    private Label forecast3;
    @FXML
    private ImageView forecastImg3;
    @FXML
    private Label forecast4;
    @FXML
    private ImageView forecastImg4;
    @FXML
    private Label forecast5;
    @FXML
    private ImageView forecastImg5;
    @FXML
    private Label forecast6;
    @FXML
    private ImageView forecastImg6;
    private SQLiteJDBC sqlConnector;
    private String key = "d5b37b5c322b7e5bf8bf71c3804c5232";
    private LocalDateTime time;

    private static String getData(String responseString) {
        JSONParser parser = new JSONParser();
        try {
            JSONObject response = (JSONObject) parser.parse(responseString);
            JSONObject current = (JSONObject) response.get("current");
            JSONObject weather = (JSONObject) ((JSONArray) current.get("weather")).get(0);

            int tempDay;
            try {
                tempDay = (int) Math.round((double) current.get("temp"));
            } catch (Exception e) {
                tempDay = (int) ((long) current.get("temp"));
            }
            String main = (String) weather.get("main");
            String icon = (String) weather.get("icon");

            temperatures[0] = tempDay;
            weathers[0] = main;
            icons[0] = icon;

            JSONArray daily = (JSONArray) response.get("daily");

            for (int i = 0; i < 3; i++) {
                JSONObject day = (JSONObject) daily.get(i);
                JSONObject temp = (JSONObject) day.get("temp");
                try {
                    tempDay = (int) Math.round((double) temp.get("day"));
                } catch (Exception e) {
                    tempDay = (int) ((long) temp.get("day"));
                }
                weather = (JSONObject) ((JSONArray) day.get("weather")).get(0);
                main = (String) weather.get("main");
                icon = (String) weather.get("icon");

                temperatures[i + 1] = tempDay;
                weathers[i + 1] = main;
                icons[i + 1] = icon;
            }
        } catch (ParseException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    private static String saveCoordinates(String responseString) {
        JSONParser parser = new JSONParser();
        try {
            JSONObject coord = (JSONObject) ((JSONObject) ((JSONObject) parser.parse(responseString)).get("city")).get("coord");
            latitude = (double) coord.get("lat");
            longitude = (double) coord.get("lon");
        } catch (ParseException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    protected void connectDatabase() {
        sqlConnector = new SQLiteJDBC();
    }

    @FXML
    protected void initialize() throws SQLException {
        connectDatabase();

        background.setImage(new Image("background.png", 700, 400, false, true));

        time = LocalDateTime.now();
        DateTimeFormatter pattern = DateTimeFormatter.ofPattern("dd-MM-yyyy  HH:mm:ss");
        labelTime.setText(time.format(pattern));

        Timeline tl = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            time = LocalDateTime.now();
            labelTime.setText(time.format(pattern));
        }));
        tl.setCycleCount(Animation.INDEFINITE);
        tl.play();

        cityField.setOnKeyPressed(e -> {
            if (e.getCode().equals(KeyCode.ENTER)) {
                try {
                    String city = cityField.getText();
                    long id = sqlConnector.getIdFromName(city);
                    coordinatesFromID(id);
                    downloadWeatherDataByCoords();
                    fillInfoLeft();
                    updateLastLeft(city);
                } catch (Exception err) {
                    System.out.println("Wrong city.");
                }
            }
        });
        cityField1.setOnKeyPressed(e -> {
            if (e.getCode().equals(KeyCode.ENTER)) {
                try {
                    String city = cityField1.getText();
                    long id = sqlConnector.getIdFromName(city);
                    coordinatesFromID(id);
                    downloadWeatherDataByCoords();
                    fillInfoRight();
                    updateLastRight(city);
                } catch (Exception err) {
                    System.out.println("Wrong city.");
                }
            }
        });

        loadLastLeft();
        loadLastRight();
    }

    private void updateLastLeft(String city) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("lastLeft.txt"));
            bw.write(city);
            bw.close();
        } catch (Exception e) {
        }
    }

    private void updateLastRight(String city) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("lastRight.txt"));
            bw.write(city);
            bw.close();
        } catch (Exception e) {
        }
    }

    private void loadLastLeft() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("lastLeft.txt"));
            String city = br.readLine();
            long id = sqlConnector.getIdFromName(city);
            coordinatesFromID(id);
            downloadWeatherDataByCoords();
            fillInfoLeft();
            cityField.setText(city);
            br.close();
        } catch (Exception e) {
        }
    }

    private void loadLastRight() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("lastRight.txt"));
            String city = br.readLine();
            long id = sqlConnector.getIdFromName(city);
            coordinatesFromID(id);
            downloadWeatherDataByCoords();
            fillInfoRight();
            cityField1.setText(city);
            br.close();
        } catch (Exception e) {
        }
    }

    private void fillInfoLeft() {
        labelTemp.setText(String.valueOf(temperatures[0]));
        imgWeather.setImage(new Image("http://openweathermap.org/img/wn/" + icons[0] + ".png", 100, 100, true, true));
        forecast1.setText(time.getDayOfWeek().toString().substring(0, 1) + time.getDayOfWeek().toString().substring(1).toLowerCase() + " - " + weathers[1] + " - " + temperatures[1] + "°");
        forecastImg1.setImage(new Image("http://openweathermap.org/img/wn/" + icons[1] + ".png", 100, 100, true, true));
        forecast2.setText(time.getDayOfWeek().plus(1).toString().substring(0, 1) + time.getDayOfWeek().plus(1).toString().substring(1).toLowerCase() + " - " + weathers[2] + " - " + temperatures[2] + "°");
        forecastImg2.setImage(new Image("http://openweathermap.org/img/wn/" + icons[2] + ".png", 100, 100, true, true));
        forecast3.setText(time.getDayOfWeek().plus(2).toString().substring(0, 1) + time.getDayOfWeek().plus(2).toString().substring(1).toLowerCase() + " - " + weathers[3] + " - " + temperatures[3] + "°");
        forecastImg3.setImage(new Image("http://openweathermap.org/img/wn/" + icons[3] + ".png", 100, 100, true, true));
    }

    private void fillInfoRight() {
        labelTemp1.setText(String.valueOf(temperatures[0]));
        imgWeather1.setImage(new Image("http://openweathermap.org/img/wn/" + icons[0] + ".png", 100, 100, true, true));
        forecast4.setText(time.getDayOfWeek().toString().substring(0, 1) + time.getDayOfWeek().toString().substring(1).toLowerCase() + " - " + weathers[1] + " - " + temperatures[1] + "°");
        forecastImg4.setImage(new Image("http://openweathermap.org/img/wn/" + icons[1] + ".png", 100, 100, true, true));
        forecast5.setText(time.getDayOfWeek().plus(1).toString().substring(0, 1) + time.getDayOfWeek().plus(1).toString().substring(1).toLowerCase() + " - " + weathers[2] + " - " + temperatures[2] + "°");
        forecastImg5.setImage(new Image("http://openweathermap.org/img/wn/" + icons[2] + ".png", 100, 100, true, true));
        forecast6.setText(time.getDayOfWeek().plus(2).toString().substring(0, 1) + time.getDayOfWeek().plus(2).toString().substring(1).toLowerCase() + " - " + weathers[3] + " - " + temperatures[3] + "°");
        forecastImg6.setImage(new Image("http://openweathermap.org/img/wn/" + icons[3] + ".png", 100, 100, true, true));
    }

    private void downloadWeatherDataByCoords() {
        URI uri = URI.create("https://api.openweathermap.org/data/2.5/onecall?lat=" + latitude + "&lon=" + longitude + "&exclude=hourly,minutely&units=metric&appid=" + key);

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder().uri(uri).build();

        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(HttpResponse::body)
                .thenApply(Controller::getData)
                .join();
    }

    private void coordinatesFromID(long id) {
        URI uri = URI.create("https://api.openweathermap.org/data/2.5/forecast?id=" + id + "&cnt=1&appid=" + key);
        //System.out.println(uri);
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder().uri(uri).build();

        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(HttpResponse::body)
                .thenApply(Controller::saveCoordinates)
                .join();
    }
}
