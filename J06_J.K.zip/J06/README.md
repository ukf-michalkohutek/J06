# J06
Weather app pouzivajuca OpenWeatherMap API

TODO: 
  - Pomocou sqlite databazy cities.sql ziskavajte ID mesta na zaklade jeho mena
  - Zobrazujte pocasie na tri dni pre 2 mesta sucasne
  - Zobrazovat aktualny datetime
  - Upravovat vzhlad aplikacie na zaklade aktualneho pocasia
  - Ukladat do jsonu posledne 3 vyhladavane lokacie - s tym, ze po spusteni aplikacie sa ukaze pocasie poslednej vyhladavanej lokacie
  
  EXTRA: 
   - V pripade, ze nebude mozne stiahnut udaje z API, aplikacia zobrazi stav na zaklade posledneho uspesneho spustenia
   - Responzivny dizajn - pri sirokouhlom okne zobrazi viac informacii 
  
  

