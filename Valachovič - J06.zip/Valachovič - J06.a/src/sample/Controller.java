package sample;

import javafx.fxml.FXML;

public class Controller {


}