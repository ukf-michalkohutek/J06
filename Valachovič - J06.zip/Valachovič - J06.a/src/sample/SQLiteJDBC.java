package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;

import java.sql.*;

public class SQLiteJDBC {

    public SQLiteJDBC(){
        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = getConnection();
            stmt = c.createStatement();
            String createTable = "CREATE TABLE IF NOT EXISTS city" +
                    " (id  INTEGER    NOT NULL, " +
                    " name  TEXT    NOT NULL, " +
                    " state  TEXT    NOT NULL, " +
                    " country  TEXT    NOT NULL, " +
                    " lon  REAL    NOT NULL, " +
                    " lat  REAL    NOT NULL )";
            stmt.executeUpdate(createTable);
            stmt.close();
            c.close();

        } catch ( Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );

        }

    }


    public Connection getConnection() {
        String url = "jdbc:sqlite:cities.db";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }


    public long getIdFromName(String name) {
        try {
            PreparedStatement ps;
            Connection con = this.getConnection();
            String sqlSelect = "SELECT id FROM city WHERE name LIKE ?";
            ps = con.prepareStatement(sqlSelect);
            ps.setString(1,name);
            ResultSet rs = ps.executeQuery();
            while ( rs.next() )
            {
                return rs.getLong("id");
            }
        } catch (SQLException e) {
            System.err.println( e.getMessage() );
        }
        return 0;
    }

}