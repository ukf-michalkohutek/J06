package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.json.JSONArray;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Main extends Application {
    Label temper1 = new Label();
    Label temper2 = new Label();
    Label temper3 = new Label();
    Label time1 = new Label();
    SQLiteJDBC SQLite1;
    private String api = "fd50f7ef09f45775cc0250f9eab10035";

    @Override
    public void start(Stage primaryStage) throws Exception{
        Group root = new Group();
        ComboBox<String> combo;

        Image bg = new Image("sample/bg.jpg");
        ImageView bgv = new ImageView(bg);
        root.getChildren().add(bgv);

        TextArea city = new TextArea();
        city.setLayoutX(50);
        city.setLayoutY(500);
        city.setPrefHeight(15);
        city.setPrefWidth(75);
        root.getChildren().add(city);
        ImageView im1 = new ImageView();
        ImageView im2 = new ImageView();
        ImageView im3 = new ImageView();
        Image sun = new Image("sample/sun.png");
        Image cloud = new Image("sample/cloud.png");
        Image rain = new Image("sample/rain.png");


        Button bt1 = new Button("Search");
        bt1.setLayoutX(50);
        bt1.setLayoutY(550);
        root.getChildren().add(bt1);

        SQLite1 = new SQLiteJDBC();
        bt1.setOnAction(event ->
        {
            long city_id = SQLite1.getIdFromName(city.getText()); //dostaneme ID mesta
            if (city_id == 0) //chybný názov
            {
                temper1.setText("Chyba");
                temper2.setText("Chyba");
                temper3.setText("Chyba");
               root.getChildren().remove(im1);
                root.getChildren().remove(im2);
                root.getChildren().remove(im3);

            }
            else
                {

                    downloadWeatherDataByID(city_id);

                    String time = resultDates.toString().substring((resultDates.toString().indexOf("\"dt_txt\""))+21,resultDates.toString().indexOf("\"dt_txt\"")+29);
                    time1.setText("Čas: " + time);

                    String cas1 = resultDates.toString().substring((resultDates.toString().indexOf("\"temp\""))+7,resultDates.toString().length());
                    String cas2 = cas1.substring(cas1.indexOf(time),cas1.length());
                    cas2 = cas2.substring(cas2.indexOf("\"temp\"")+7,cas2.length());
                    String cas3 = cas2.substring(cas2.indexOf(time),cas2.length());
                    cas3 = cas3.substring(cas3.indexOf("\"temp\"")+7,cas3.length());

                    temper1.setText((Integer.parseInt(cas1.substring(0,3))-272)+"");
                    temper2.setText((Integer.parseInt(cas2.substring(0,3))-272)+"");
                    temper3.setText((Integer.parseInt(cas3.substring(0,3))-272)+"");

                    if ((Integer.parseInt(temper1.getText())) < 10)
                    {

                        im1.setImage(rain);
                    }
                    else if ((Integer.parseInt(temper1.getText())) < 25)
                    {

                        im1.setImage(cloud);
                    }
                    else
                    {

                        im1.setImage(sun);
                    }

                    if ((Integer.parseInt(temper2.getText())) < 10)
                    {

                        im2.setImage(rain);
                    }
                    else if ((Integer.parseInt(temper2.getText())) < 25)
                    {

                        im2.setImage(cloud);
                    }
                    else
                    {

                        im2.setImage(sun);
                    }

                    if ((Integer.parseInt(temper3.getText())) < 10)
                    {
                        im3.setImage(rain);

                    }
                    else if ((Integer.parseInt(temper3.getText())) < 25)
                    {

                        im3.setImage(cloud);
                    }
                    else
                    {

                        im3.setImage(sun);
                    }

                }

        });


        temper1.setLayoutX(50);
        temper1.setLayoutY(100);
        im1.setX(150);
        im1.setY(0);
        im1.setScaleX(0.1);
        im1.setScaleY(0.1);
        root.getChildren().add(temper1);


        temper2.setLayoutX(50);
        temper2.setLayoutY(200);
        im2.setX(150);
        im2.setY(100);
        im2.setScaleX(0.1);
        im2.setScaleY(0.1);
        root.getChildren().add(temper2);


        temper3.setLayoutX(50);
        temper3.setLayoutY(300);
        im3.setX(150);
        im3.setY(200);
        im3.setScaleX(0.1);
        im3.setScaleY(0.1);
        root.getChildren().add(temper3);

        root.getChildren().add(im1);
        root.getChildren().add(im2);
        root.getChildren().add(im3);
        time1.setLayoutX(200);
        time1.setLayoutY(550);
        root.getChildren().add(time1);

        primaryStage.setTitle("Weather - Valachovič");
        primaryStage.setScene(new Scene(root, 500, 600));
        primaryStage.show();





    }
    private void downloadWeatherDataByID(long id) {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder().uri(URI.create("https://api.openweathermap.org/data/2.5/forecast?id="+id+"&appid="+api)).build();

        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(HttpResponse::body)
                .thenApply(Main::parseCurrentWeather)
                .join();

    }
    static JSONArray resultDates;

    private static String parseCurrentWeather(String response)  {
        resultDates = new JSONArray("[" + response + "]" );
        
        return null;
    }

    public static void main(String[] args) {
        launch(args); } }

